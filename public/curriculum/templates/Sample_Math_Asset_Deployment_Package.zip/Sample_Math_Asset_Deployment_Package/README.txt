DREAMSCAPE — SAMPLE MATHEMATICS ASSET DEPLOYMENT PACKAGE
===========================================================

PURPOSE
-------
This is a TEMPLATE showing the exact folder and Deployment_Manifest.json
structure expected by Curriculum Operations > Asset Deployment.

DO NOT DEPLOY THIS SAMPLE UNCHANGED.
Replace the sample question IDs, question codes, quiz codes, file names,
storage paths, dimensions and alt text with the real values for your batch.

HOW TO USE
----------
1. Copy this folder as the starting point for a real deployment package.
2. Keep exactly one file named Deployment_Manifest.json in the package.
3. Put all image binaries somewhere inside the same extracted package folder.
4. For Mathematics P1, every storage_path must begin with:
      math/p1/
5. Mathematics uses the Supabase bucket:
      core-question-assets
6. The batch name must follow:
      p<level>-math-<descriptive-batch-name>
   Example:
      p1-math-number-bonds-batch-07
7. Each prompt image mapping uses:
      "image_role": "prompt"
8. Each Mathematics option image mapping uses:
      "image_role": "option"
      "option_index": 0
   option_index is ZERO-BASED:
      0 = first option (A)
      1 = second option (B)
      2 = third option (C)
      3 = fourth option (D)
9. Each Mathematics mapping must include the REAL:
      question_id
      question_code
   The question_code must belong to the correct level, e.g. MATH-P1-...
10. Every asset and mapping should have:
      "qc_status": "PASS"
    and the manifest summary should contain:
      "qc_failures": 0
11. Extract the completed ZIP before importing.
12. In Asset Deployment, select the COMPLETE extracted folder.
13. The system validates file presence and package rules before upload.
14. Upload assets.
15. Apply mappings.
16. Confirm the final prompt/option mapping verification counts.

PACKAGE CONTENTS
----------------
Deployment_Manifest.json
math/p1/sample-asset-deployment/prompt/sample-number-bond.svg
math/p1/sample-asset-deployment/options/sample-option-a.svg
math/p1/sample-asset-deployment/options/sample-option-b.svg

WHAT THIS SAMPLE DEMONSTRATES
-----------------------------
- 1 prompt image attached to a Mathematics question.
- 2 answer-option images attached by zero-based option_index.
- Multiple mappings for the same question.
- Storage-path mirroring between the manifest and package files.
- QC fields and summary counts.

IMPORTANT
---------
The sample UUID and codes are intentionally illustrative and do not identify
a live DREAMSCAPE question. Copy the structure, then replace the values with
the actual IDs/codes from the curriculum batch you are deploying.
